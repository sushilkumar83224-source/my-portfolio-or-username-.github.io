// 5-Year Holidays & Festivals (2026–2030)
// type: "holiday" = national/gazetted, "festival" = religious/cultural
const events = {
  // 2026
  "2026-01-01": { label: "New Year's Day", type: "holiday" },
  "2026-01-14": { label: "Makar Sankranti", type: "festival" },
  "2026-01-26": { label: "Republic Day", type: "holiday" },
  "2026-02-16": { label: "Maha Shivaratri", type: "festival" },
  "2026-03-03": { label: "Holi", type: "festival" },
  "2026-03-25": { label: "Ram Navami", type: "festival" },
  "2026-04-03": { label: "Good Friday", type: "holiday" },
  "2026-04-14": { label: "Ambedkar Jayanti", type: "holiday" },
  "2026-05-01": { label: "May Day", type: "holiday" },
  "2026-06-06": { label: "Eid al-Fitr", type: "festival" },
  "2026-08-15": { label: "Independence Day", type: "holiday" },
  "2026-08-28": { label: "Raksha Bandhan", type: "festival" },
  "2026-09-05": { label: "Janmashtami", type: "festival" },
  "2026-10-02": { label: "Gandhi Jayanti", type: "holiday" },
  "2026-10-18": { label: "Dussehra", type: "festival" },
  "2026-11-08": { label: "Diwali", type: "festival" },
  "2026-11-27": { label: "Guru Nanak Jayanti", type: "festival" },
  "2026-12-25": { label: "Christmas", type: "holiday" },

  // 2027
  "2027-01-01": { label: "New Year's Day", type: "holiday" },
  "2027-01-14": { label: "Makar Sankranti", type: "festival" },
  "2027-01-26": { label: "Republic Day", type: "holiday" },
  "2027-02-05": { label: "Maha Shivaratri", type: "festival" },
  "2027-02-21": { label: "Holi", type: "festival" },
  "2027-04-02": { label: "Good Friday", type: "holiday" },
  "2027-04-14": { label: "Ambedkar Jayanti", type: "holiday" },
  "2027-05-01": { label: "May Day", type: "holiday" },
  "2027-05-26": { label: "Eid al-Fitr", type: "festival" },
  "2027-08-15": { label: "Independence Day", type: "holiday" },
  "2027-08-26": { label: "Raksha Bandhan", type: "festival" },
  "2027-09-04": { label: "Janmashtami", type: "festival" },
  "2027-10-02": { label: "Gandhi Jayanti", type: "holiday" },
  "2027-10-17": { label: "Dussehra", type: "festival" },
  "2027-10-28": { label: "Diwali", type: "festival" },
  "2027-11-16": { label: "Guru Nanak Jayanti", type: "festival" },
  "2027-12-25": { label: "Christmas", type: "holiday" },

  // 2028
  "2028-01-01": { label: "New Year's Day", type: "holiday" },
  "2028-01-14": { label: "Makar Sankranti", type: "festival" },
  "2028-01-26": { label: "Republic Day", type: "holiday" },
  "2028-02-13": { label: "Holi", type: "festival" },
  "2028-02-17": { label: "Maha Shivaratri", type: "festival" },
  "2028-03-22": { label: "Ram Navami", type: "festival" },
  "2028-04-14": { label: "Ambedkar Jayanti", type: "holiday" },
  "2028-04-14": { label: "Baisakhi", type: "festival" },
  "2028-04-21": { label: "Good Friday", type: "holiday" },
  "2028-05-01": { label: "May Day", type: "holiday" },
  "2028-05-15": { label: "Eid al-Fitr", type: "festival" },
  "2028-08-15": { label: "Independence Day", type: "holiday" },
  "2028-09-02": { label: "Janmashtami", type: "festival" },
  "2028-09-13": { label: "Raksha Bandhan", type: "festival" },
  "2028-10-02": { label: "Gandhi Jayanti", type: "holiday" },
  "2028-10-05": { label: "Dussehra", type: "festival" },
  "2028-10-16": { label: "Diwali", type: "festival" },
  "2028-11-04": { label: "Guru Nanak Jayanti", type: "festival" },
  "2028-12-25": { label: "Christmas", type: "holiday" },

  // 2029
  "2029-01-01": { label: "New Year's Day", type: "holiday" },
  "2029-01-14": { label: "Makar Sankranti", type: "festival" },
  "2029-01-26": { label: "Republic Day", type: "holiday" },
  "2029-02-01": { label: "Maha Shivaratri", type: "festival" },
  "2029-03-02": { label: "Holi", type: "festival" },
  "2029-04-06": { label: "Good Friday", type: "holiday" },
  "2029-04-14": { label: "Ambedkar Jayanti", type: "holiday" },
  "2029-05-01": { label: "May Day", type: "holiday" },
  "2029-05-05": { label: "Eid al-Fitr", type: "festival" },
  "2029-08-15": { label: "Independence Day", type: "holiday" },
  "2029-08-23": { label: "Raksha Bandhan", type: "festival" },
  "2029-08-31": { label: "Janmashtami", type: "festival" },
  "2029-10-02": { label: "Gandhi Jayanti", type: "holiday" },
  "2029-10-15": { label: "Dussehra", type: "festival" },
  "2029-11-04": { label: "Diwali", type: "festival" },
  "2029-11-23": { label: "Guru Nanak Jayanti", type: "festival" },
  "2029-12-25": { label: "Christmas", type: "holiday" },

  // 2030
  "2030-01-01": { label: "New Year's Day", type: "holiday" },
  "2030-01-14": { label: "Makar Sankranti", type: "festival" },
  "2030-01-26": { label: "Republic Day", type: "holiday" },
  "2030-02-19": { label: "Maha Shivaratri", type: "festival" },
  "2030-02-21": { label: "Holi", type: "festival" },
  "2030-03-21": { label: "Ram Navami", type: "festival" },
  "2030-03-29": { label: "Good Friday", type: "holiday" },
  "2030-04-14": { label: "Ambedkar Jayanti", type: "holiday" },
  "2030-04-14": { label: "Baisakhi", type: "festival" },
  "2030-04-24": { label: "Eid al-Fitr", type: "festival" },
  "2030-05-01": { label: "May Day", type: "holiday" },
  "2030-08-15": { label: "Independence Day", type: "holiday" },
  "2030-08-13": { label: "Raksha Bandhan", type: "festival" },
  "2030-08-21": { label: "Janmashtami", type: "festival" },
  "2030-10-02": { label: "Gandhi Jayanti", type: "holiday" },
  "2030-10-04": { label: "Dussehra", type: "festival" },
  "2030-10-24": { label: "Diwali", type: "festival" },
  "2030-11-12": { label: "Guru Nanak Jayanti", type: "festival" },
  "2030-12-25": { label: "Christmas", type: "holiday" }
};

const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const weekdayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function getDaysInMonth(year, monthIndex) {
  return new Date(year, monthIndex + 1, 0).getDate();
}

function getFirstDayOfMonth(year, monthIndex) {
  let day = new Date(year, monthIndex, 1).getDay();
  return (day + 6) % 7; // Monday = 0 ... Sunday = 6
}

function formatDateKey(year, monthIndex, day) {
  const m = String(monthIndex + 1).padStart(2, "0");
  const d = String(day).padStart(2, "0");
  return `${year}-${m}-${d}`;
}

function createMonth(year, monthIndex) {
  const monthDiv = document.createElement("div");
  monthDiv.className = "month";

  const header = document.createElement("div");
  header.className = "month-header";
  header.textContent = `${monthNames[monthIndex]} ${year}`;
  monthDiv.appendChild(header);

  const weekdaysDiv = document.createElement("div");
  weekdaysDiv.className = "weekdays";
  weekdayNames.forEach(name => {
    const wd = document.createElement("div");
    wd.textContent = name;
    weekdaysDiv.appendChild(wd);
  });
  monthDiv.appendChild(weekdaysDiv);

  const daysDiv = document.createElement("div");
  daysDiv.className = "days";

  const firstDay = getFirstDayOfMonth(year, monthIndex);
  const totalDays = getDaysInMonth(year, monthIndex);

  for (let i = 0; i < firstDay; i++) {
    const empty = document.createElement("div");
    empty.className = "day empty";
    daysDiv.appendChild(empty);
  }

  for (let day = 1; day <= totalDays; day++) {
    const key = formatDateKey(year, monthIndex, day);
    const dayDiv = document.createElement("div");
    dayDiv.className = "day";
    dayDiv.textContent = day;

    if (events[key]) {
      const info = events[key];
      dayDiv.classList.add(info.type);
      dayDiv.title = info.label;
    }

    daysDiv.appendChild(dayDiv);
  }

  monthDiv.appendChild(daysDiv);
  return monthDiv;
}

function buildYearCalendar(year) {
  const container = document.getElementById("yearCalendar");
  container.innerHTML = "";

  for (let m = 0; m < 12; m++) {
    const monthEl = createMonth(year, m);
    container.appendChild(monthEl);
  }
}

// Year selector
const yearSelect = document.getElementById("yearSelect");
yearSelect.addEventListener("change", () => {
  const selectedYear = parseInt(yearSelect.value, 10);
  buildYearCalendar(selectedYear);
});

// Initial load: 2026
buildYearCalendar(2026);